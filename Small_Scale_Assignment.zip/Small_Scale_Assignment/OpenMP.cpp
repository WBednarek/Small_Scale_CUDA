#include "OpenMP.h"



OpenMP::OpenMP()
{
}


OpenMP::~OpenMP()
{
}
