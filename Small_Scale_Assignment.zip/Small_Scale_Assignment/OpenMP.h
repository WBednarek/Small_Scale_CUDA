#pragma once
class OpenMP
{
public:
	OpenMP();
	~OpenMP();
};

